import {sqliteTable,text,index} from 'drizzle-orm/sqlite-core';
export const reports=sqliteTable('reports',{month:text('month').primaryKey(),key:text('object_key').notNull(),filename:text('filename').notNull(),generated:text('generated').notNull()});
export const settings=sqliteTable('settings',{id:text('id').primaryKey(),value:text('value').notNull()});
export const documents=sqliteTable('documents',{id:text('id').primaryKey(),tenant:text('tenant').notNull(),kind:text('kind').notNull(),logicalKey:text('logical_key').notNull(),created:text('created').notNull(),objectKey:text('object_key').notNull()},t=>[index('documents_tenant_kind_key').on(t.tenant,t.kind,t.logicalKey)]);
