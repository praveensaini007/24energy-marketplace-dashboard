import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "24 ENERGY | Marketplace P&L",
  description: "Monthly sales, returns, settlements and profitability for 24 ENERGY.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
