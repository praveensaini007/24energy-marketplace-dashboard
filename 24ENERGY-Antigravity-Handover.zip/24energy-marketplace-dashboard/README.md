# 24 ENERGY Marketplace Dashboard

Private business application for Praveen / Geaan Electronics. Source snapshot: `61c8d8c76ad1e69108a239b7532e461d72562954`, 5 October 2026. This handover adds documentation and GitHub validation configuration to that source without changing the live website.

**Start with [START_HERE.md](START_HERE.md).**

## Package status

- Application source, locked dependencies, database migrations and bundled business seed data: included.
- Private GitHub repository: https://github.com/praveensaini007/24energy-marketplace-dashboard (source ZIP and bootstrap entrypoint). Expanded source push remains a local setup step.
- Live production database, uploaded originals and their version history: NOT EXPORTED.
- GitHub-to-Sites automatic deployment or synchronization: NOT CONFIGURED.
- Clean Windows installation and local browser sign-in: instructions supplied, not yet verified on the user's computer.
- Existing production website remains hosted privately by Sites.

## Documentation

| Document | Purpose |
|---|---|
| [HANDOVER](docs/HANDOVER.md) | Current status and next tasks |
| [LOCAL_SETUP](docs/LOCAL_SETUP.md) | Windows/Antigravity development setup |
| [GITHUB_SETUP](docs/GITHUB_SETUP.md) | Private repository creation and access |
| [BUSINESS_RULES](docs/BUSINESS_RULES.md) | Authoritative recent calculation decisions |
| [ARCHITECTURE](docs/ARCHITECTURE.md) | Components, storage and workflows |
| [DATA_AND_HOSTING](docs/DATA_AND_HOSTING.md) | Data backup, deployment boundary and migration |
| [COLLABORATION](docs/COLLABORATION.md) | Switching between assistants |
| [SYSTEM](docs/SYSTEM.md) | Earlier detailed system notes; current business rules take precedence |
| [STARTER_REFERENCE](docs/STARTER_REFERENCE.md) | Framework-specific reference from the original starter |

Contains confidential seed reports under `data/`. Keep the repository private. No Git credentials, environment secrets, dependency folders, production storage backups or login cookies are included.
