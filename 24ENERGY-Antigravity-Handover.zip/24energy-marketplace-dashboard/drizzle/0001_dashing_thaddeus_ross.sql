CREATE TABLE `documents` (
	`id` text PRIMARY KEY NOT NULL,
	`tenant` text NOT NULL,
	`kind` text NOT NULL,
	`logical_key` text NOT NULL,
	`created` text NOT NULL,
	`object_key` text NOT NULL
);
