import {Line,Master,MarketReport,SettlementTarget,key,total} from './marketplace';
export type MappedLine=Line&{month:string,report:MarketReport,master?:Master,state:string};
export type ModelCosts=Record<string,{product:number,packaging:number}>;
export type ComparisonBasis=ModelCosts|Map<string,SettlementTarget>;
const bankCache=new WeakMap<MarketReport,{gross:number,residual:number}|null>();
export function settlementVariance(lines:MappedLine[],targets:Map<string,SettlementTarget>){
 if(!lines.length)return null;let actual=0,target=0;
 for(const o of lines){
  const t=o.master&&targets.get(key(o.master.model));
  if(o.net!==0&&(!t||!o.master||!Number.isFinite(t.taxed)))return null;
  if(typeof o.bank!=='number'||!Number.isFinite(o.bank))return null;
  let stats=bankCache.get(o.report);
  if(stats===undefined){const bank=o.report.summary['bank settlement (projected)'];stats=Number.isFinite(bank)&&o.report.orders.every(x=>typeof x.bank==='number'&&Number.isFinite(x.bank))?{gross:total(o.report.orders,'gross'),residual:bank-total(o.report.orders,'bank')}:null;bankCache.set(o.report,stats);}
  if(!stats||(!stats.gross&&Math.abs(stats.residual)>0.005))return null;
  actual+=o.bank+stats.residual*o.gross/(stats.gross||1);
  if(o.net!==0)target+=o.net*o.master!.pack*t!.taxed;
 }
 return actual-target;
}

const reportCache=new WeakMap<MarketReport,{gross:number,adjustment:number}>();
export function reportStats(r:MarketReport){let v=reportCache.get(r);if(!v){v={gross:total(r.orders,'gross'),adjustment:(r.summary['earnings on platform']||0)-total(r.orders,'earnings')};reportCache.set(r,v);}return v;}
export function adjustment(o:MappedLine){const v=reportStats(o.report);return v.adjustment*o.gross/(v.gross||1);}
export function indexMaster(master:Master[]){const exact=new Map<string,Master>(),bySKU=new Map<string,Master[]>();for(const m of master){exact.set(key(m.platform,m.sku),m);const k=key(m.sku);if(!bySKU.has(k))bySKU.set(k,[]);bySKU.get(k)!.push(m);}const fallback=new Map<string,Master>();for(const [k,v] of bySKU)if(new Set(v.map(m=>key(m.brand,m.category,m.model,m.pack))).size===1)fallback.set(k,v[0]);return (o:Line)=>{const m=exact.get(key(o.channel,o.sku));if(m)return {master:m,state:'Matched'};const f=fallback.get(key(o.sku));return {master:f,state:f?'Channel differs':'Unmapped'};};}
export const modelKey=(o:MappedLine)=>o.master?key(o.master.brand,o.master.model):'unmapped';
export function contribution(lines:MappedLine[],costs:ComparisonBasis){if(costs instanceof Map)return settlementVariance(lines,costs);if(!lines.length||lines.some(o=>!o.master||!costs[modelKey(o)]))return null;return lines.reduce((sum,o)=>{const c=costs[modelKey(o)];return sum+o.earnings+adjustment(o)-o.net*o.master!.pack*c.product-(o.gross-o.cancel)*c.packaging},0);}
export function returnRate(lines:Line[]){const g=total(lines,'gross');return g?(total(lines,'rto')+total(lines,'rvp'))/g:null;}
export function assessListing(lines:MappedLine[],pool:MappedLine[],costs:ComparisonBasis,min=30){const first=lines[0],gross=total(lines,'gross'),rate=returnRate(lines);const peers=first?.master?pool.filter(o=>o.channel===first.channel&&o.master?.category===first.master?.category&&o.master?.pack===first.master?.pack):[];const peerRate=returnRate(peers),profit=contribution(lines,costs);let label='More data needed',priority=5;
 if(gross===0){label='No orders';priority=7;}
 else if(lines.some(o=>o.state!=='Matched')){label='Review mapping';priority=6;}
 else if(gross<min){label='Small sample';priority=5;}
 else if(lines.some(o=>['IN_TRANSIT','RETURN_REQUESTED'].includes(o.status))){label='Await final outcomes';priority=4;}
 else if(peerRate==null){label='No category benchmark';priority=5;}
 else if(costs instanceof Map?(profit!=null&&profit<0):((profit!=null&&profit<=0)||total(lines,'earnings')<=0)){label=costs instanceof Map?'Below settlement target':'Review earnings';priority=3;}
 else if(rate!>peerRate){label='Review returns';priority=2;}
 else if(profit==null){label=costs instanceof Map?'Check target / settlement':'Promising · add costs';priority=1;}
 else{label='Focus candidate';priority=0;}
 return {label,priority,gross,rate,peerRate,peerUnits:total(peers,'gross'),profit};
}

export function averageRvpFee(lines:Line[]){const net=total(lines,'net'),rvp=lines.filter(o=>o.rvp>0);return net>0&&!rvp.some(o=>o.rto>0&&o.reverse!==0)?(-total(rvp,'reverse')/net||0):null;}
export function listingFinancialAlert(lines:Line[]){const bank=lines.length&&lines.every(o=>typeof o.bank==='number'&&Number.isFinite(o.bank))?total(lines,'bank'):null;const negativeBank=bank!==null&&bank<0,negativeEarnings=total(lines,'earnings')<0;return {bank,negativeBank,negativeEarnings,flagged:negativeBank||negativeEarnings,label:negativeBank?'Negative settlement':negativeEarnings?'Negative earnings':''};}

// Historical pricing allowance; never written into product cost or deducted again.
export function rvpRecoveryIndex(reports:MarketReport[],lookup:ReturnType<typeof indexMaster>,platform:string,brand:string,category:string,selectedMonths?:string[]){
 const eligible=reports.filter(r=>platform==='All platforms'||r.platform===platform||(platform==='Shopsy'&&r.platform==='Flipkart'));
 const months=[...new Set(eligible.map(r=>r.month))].filter(m=>!selectedMonths||selectedMonths.includes(m)).sort();
 const models=new Map<string,Line[]>(),listings=new Map<string,Line[]>();
 for(const r of eligible){if(!months.includes(r.month))continue;for(const o of r.orders){if(platform!=='All platforms'&&o.channel!==platform)continue;const m=lookup(o).master;if(brand!=='All brands'&&m?.brand!==brand||category!=='All categories'&&m?.category!==category)continue;const mk=m?key(m.brand,m.model):'unmapped',sk=key(o.channel,o.sku);for(const [map,k] of [[models,mk],[listings,sk]] as const){if(!map.has(k))map.set(k,[]);map.get(k)!.push(o);}}}
 const amounts=(map:Map<string,Line[]>)=>new Map([...map].map(([k,a])=>{const fee=averageRvpFee(a);return [k,fee==null?null:Math.max(0,fee)] as const;}));
 return {months,models:amounts(models),listings:amounts(listings)};
}

export function desiredSettlement(lines:MappedLine[],targets:Map<string,SettlementTarget>,basis:'base'|'taxed',fallback?:Master){const net=total(lines,'net');if(net<=0){const t=fallback&&targets.get(key(fallback.model));return t&&fallback?t[basis]*fallback.pack:null;}let sum=0;for(const o of lines){if(o.net===0)continue;const t=o.master&&targets.get(key(o.master.model));if(!t||!o.master)return null;sum+=o.net*o.master.pack*t[basis];}return sum/net;}

export function rvpFeePerReturnedUnit(lines:Line[]){const returned=total(lines,'rvp'),rvp=lines.filter(o=>o.rvp>0);return returned>0&&!rvp.some(o=>o.rto>0&&o.reverse!==0)?(-total(rvp,'reverse')/returned||0):null;}
