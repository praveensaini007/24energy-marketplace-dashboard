import {key} from './marketplace';
import {MappedLine} from './performance';
export type ReturnKind='all'|'rvp'|'rto';
export function previousMonth(month:string){const [y,m]=month.split('-').map(Number);return new Date(Date.UTC(y,m-2,1)).toISOString().slice(0,7);}
export function returnWatch(lines:MappedLine[],pool:MappedLine[],kind:ReturnKind){
 const benchmarks=new Map<string,{gross:number,returned:number}>();const returned=(o:MappedLine)=>kind==='rvp'?o.rvp:kind==='rto'?o.rto:o.rvp+o.rto;
 const benchKey=(o:MappedLine)=>key(o.month,o.channel,o.master?.category,o.master?.pack);
 for(const o of pool){if(!o.master)continue;const k=benchKey(o),a=benchmarks.get(k)||{gross:0,returned:0};a.gross+=o.gross;a.returned+=returned(o);benchmarks.set(k,a);}
 const groups=new Map<string,{month:string,channel:string,sku:string,model:string,category:string,pack:number|null,gross:number,rvp:number,rto:number,returned:number,reverse:number,open:number,mapping:boolean,benchKey:string}>();
 for(const o of lines){const k=key(o.month,o.channel,o.sku);let a=groups.get(k);if(!a){a={month:o.month,channel:o.channel,sku:o.sku,model:o.master?.model||'Unmapped',category:o.master?.category||'—',pack:o.master?.pack||null,gross:0,rvp:0,rto:0,returned:0,reverse:0,open:0,mapping:false,benchKey:benchKey(o)};groups.set(k,a);}a.gross+=o.gross;a.rvp+=o.rvp;a.rto+=o.rto;a.returned+=returned(o);a.reverse-=o.reverse;a.open+=['IN_TRANSIT','RETURN_REQUESTED'].includes(o.status)?1:0;a.mapping ||=o.state!=='Matched';}
 return [...groups.values()].map(a=>{const b=benchmarks.get(a.benchKey),p=groups.get(key(previousMonth(a.month),a.channel,a.sku));const rate=a.gross?100*a.returned/a.gross:null,categoryRate=b?.gross?100*b.returned/b.gross:null,previousRate=p?.gross?100*p.returned/p.gross:null;return {...a,rate,categoryRate,previousRate,change:rate!=null&&previousRate!=null?rate-previousRate:null,gap:rate!=null&&categoryRate!=null?rate-categoryRate:null};});
}
export function rankReturns(rows:ReturnType<typeof returnWatch>,month:string,sort:string,min:number){return rows.filter(r=>r.month===month&&r.returned>0&&(sort!=='rate'||r.gross>=min)).sort((a,b)=>sort==='rate'?(b.rate||0)-(a.rate||0)||b.returned-a.returned:b.returned-a.returned||(b.rate||0)-(a.rate||0));}
