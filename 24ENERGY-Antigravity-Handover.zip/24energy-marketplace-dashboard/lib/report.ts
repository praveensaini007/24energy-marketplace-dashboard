import * as XLSX from 'xlsx';
export type SKU={sku:string,gross:number,rto:number,rvp:number,cancel:number,net:number,sales:number,expenses:number,reverse:number,earnings:number,pending:number};
export type Order={id:string,item:string,sku:string,channel:string,fulfillment:string,payment:string,status:string,gross:number,rto:number,rvp:number,cancel:number,net:number,sales:number,reverse:number,earnings:number,pending:number};
export type Report={month:string,period:string,generated:string,filename:string,summary:Record<string,number>,skus:SKU[],orders:Order[],warnings:string[]};
export const clean=(v:any)=>String(v??'').replace(/[•:]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
const num=(v:any)=>{if(v==null||v==='')return 0;const n=Number(v);if(!Number.isFinite(n))throw Error('A numeric field contains invalid data.');return n};
export function parseWorkbook(bytes:ArrayBuffer,filename:string):Report{
 const w=XLSX.read(bytes,{type:'array',dense:true});
 const read=(name:string)=>{const s=w.Sheets[name];if(!s)throw Error(`Missing sheet: ${name}. Upload the original Flipkart P&L Excel report.`);
 const data=(s as any)['!data']||s;if(Array.isArray(data)){let endR=data.length-1,endC=0;for(const row of data)if(row)endC=Math.max(endC,row.length-1);s['!ref']=XLSX.utils.encode_range({s:{r:0,c:0},e:{r:endR,c:endC}})}
 return XLSX.utils.sheet_to_json<any[]>(s,{header:1,defval:null,blankrows:false});};
 const summaryRows=read('Overall Summary'),sk=read('SKU-level P&L'),ord=read('Orders P&L');
 const period=String(summaryRows.find(r=>clean(r[0]).startsWith('orders rec'))?.[1]??'');
 const dates=period.match(/\d{4}-\d{2}-\d{2}/g);if(!dates||dates.length!==2)throw Error('Cannot identify the report period.');
 const month=dates[0].slice(0,7);if(dates[1].slice(0,7)!==month||dates[0].slice(-2)!=='01'||Number(dates[1].slice(-2))!==new Date(Number(month.slice(0,4)),Number(month.slice(5)),0).getDate())throw Error('Please upload one complete calendar month per report, to prevent overlapping periods.');
 for(const [rows,index,label] of [[sk,2,'gross units (#)'],[sk,4,'rto (logistics return)'],[sk,5,'rvp (customer return)'],[ord,1,'order id'],[ord,34,'reverse shipping fee']] as any[]){if(clean(rows[index===4||index===5||index===34?1:0]?.[index])!==label)throw Error('The report columns have changed. This file needs review before import.');}
 const summary:Record<string,number>={};for(const r of summaryRows)if(typeof r[1]==='number')summary[clean(r[0])]=r[1];
 const required=['gross sales','estimated net sales','accounted net sales (seller price)','total expenses','bank settlement (projected)','earnings on platform','reverse shipping fee','rto (logistics return)','rvp (customer return)'];for(const k of required)if(!(k in summary))throw Error(`Missing summary value: ${k}`);
 const skus=sk.slice(2).filter(r=>r[0]&&typeof r[2]==='number').map(r=>({sku:String(r[0]),gross:num(r[2]),rto:num(r[4]),rvp:num(r[5]),cancel:num(r[6]),net:num(r[7]),sales:num(r[12]),expenses:num(r[13]),reverse:num(r[20]),earnings:num(r[42]),pending:num(r[47])}));
 const orders=ord.slice(2).filter(r=>r[1]).map(r=>({id:String(r[1]),item:String(r[2]),sku:String(r[3]),channel:String(r[5]),fulfillment:String(r[4]),payment:String(r[6]),status:String(r[7]),gross:num(r[9]),rto:num(r[11]),rvp:num(r[12]),cancel:num(r[13]),net:num(r[14]),sales:r[21]==='Generation in progress'?0:num(r[21]),reverse:num(r[34]),earnings:num(r[53]),pending:num(r[57])}));
 if(!orders.length||!skus.length)throw Error('No order or SKU data found.');
 if(new Set(orders.map(o=>o.item)).size!==orders.length)throw Error('Duplicate Order Item IDs detected. Import stopped to prevent double-counting.');
 for(const k of ['gross','rto','rvp','cancel','net'] as const){if(Math.abs(sum(skus,k)-sum(orders,k))>.01)throw Error(`SKU and order ${k} totals do not reconcile.`)}
 const grossRow=summaryRows.find(r=>clean(r[0])==='gross sales');if(Math.abs(num(grossRow?.[2])-sum(skus,'gross'))>.01)throw Error('Gross unit totals do not reconcile with the summary.');
 if(Math.abs(sum(skus,'reverse')-summary['reverse shipping fee'])>1)throw Error('Reverse shipping totals do not reconcile.');
 const warnings:string[]=[];const pendingFinancial=ord.slice(2).filter(r=>r[21]==='Generation in progress').length;if(pendingFinancial)warnings.push(`${pendingFinancial} order-item sales amounts are still being generated; their sales values are unavailable. Summary figures are as reported.`);const open=orders.filter(o=>['IN_TRANSIT','RETURN_REQUESTED'].includes(o.status)).length;if(open)warnings.push(`${open} order-item rows remain in transit or return requested. Outcomes may change in a refreshed report.`);
 return {month,period,generated:String(summaryRows.find(r=>clean(r[0])==='generated on')?.[1]??''),filename,summary,skus,orders,warnings};
}
export function sum(rows:any[],key:string){return rows.reduce((a,r)=>a+(Number(r[key])||0),0)}
export function metrics(reports:Report[]){const skus=reports.flatMap(r=>r.skus),orders=reports.flatMap(r=>r.orders);const summary:Record<string,number>={};for(const r of reports)for(const [k,v]of Object.entries(r.summary))summary[k]=(summary[k]||0)+v;return {summary,gross:sum(skus,'gross'),rto:sum(skus,'rto'),rvp:sum(skus,'rvp'),cancel:sum(skus,'cancel'),net:sum(skus,'net'),orderCount:new Set(orders.map(o=>o.id)).size,returnOrders:new Set(orders.filter(o=>o.rto+o.rvp>0).map(o=>o.id)).size};}
export function aggregateSKU(reports:Report[]){const map=new Map<string,SKU>();for(const r of reports)for(const s of r.skus){if(!map.has(s.sku))map.set(s.sku,{...s});else{const a=map.get(s.sku)!;for(const k of Object.keys(s).filter(k=>k!=='sku'))(a as any)[k]+=(s as any)[k]}}return [...map.values()]}
