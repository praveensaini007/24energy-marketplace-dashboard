# Local development in Antigravity

## Requirements

Node.js >=22.13.0 (Node 22 recommended), Git, and pnpm 11.25.0 as pinned in package.json. Open a terminal in the extracted/cloned project root. Use Windows PowerShell, macOS or Linux. Do not copy node_modules from ChatGPT.

```sh
node --version
git --version
npm install --global pnpm@11.25.0
pnpm install --frozen-lockfile
pnpm run build
```

Use pnpm and the existing pnpm-lock.yaml; the older starter README's npm-ci examples are not the install path for this snapshot (there is no package-lock.json).

## Initialize the local database once

The build generates dist/server/wrangler.json. For a fresh local database only, apply these files in order:

```sh
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_demonic_amazoness.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_dashing_thaddeus_ross.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0002_chubby_gargoyle.sql
pnpm run dev
```

Do not rerun CREATE TABLE migrations against an initialized database. All commands above use --local, not production. Preserve .wrangler/state across restarts to retain local uploads.

## Local sign-in

Use the loopback URL printed by the dev server (normally http://localhost:5173). Navigate to `/signin-with-chatgpt?return_to=/` on that same origin. The portable development plugin signs in as `seedy@sites.test`. This is a local test seller, not Praveen's live account, so an empty workspace is expected. Upload test files through Upload & settings to populate it.

A clean clone defaults to portable mode; .sites-runtime is intentionally omitted. The development auth mock accepts loopback requests only and is not included in production builds. Do not change its identity to impersonate the production owner or forward production cookies. `pnpm start` previews a built worker but does not simulate sign-in; use `pnpm run dev` for the local login flow.

## Validation

```sh
pnpm exec tsc --noEmit
node scripts/verify-marketplace.mjs
node scripts/verify-performance.mjs
node scripts/verify-gmv.mjs
pnpm run build
```

Browser checks: local sign-in, master upload, settlement target upload, report upload, refresh persistence, model search, pack-of-2 target, missing-target display, month/year arrows, duplicate report replacement, GMV selected dates and downloads. Confirm totals with known report values. The bundled seed files are confidential historical data, not a backup of every current upload.

## Troubleshooting

- 401 / sign-in error: use the explicit local sign-in path in the same localhost origin; confirm portable dev mode.
- Missing table: build and initialize the three local migrations once.
- Empty workspace: expected for local test identity; upload local test reports.
- Port busy: stop the old dev process or run `pnpm run dev -- --port 5174`, then use that origin for sign-in.
- Missing executable / lock mismatch: confirm Node and pnpm versions; retain lockfile and investigate the error instead of upgrading everything.
- Production login error: use the authorized ChatGPT account in a normal browser; capture the actual error. Local mock sign-in does not grant production access.
