# Architecture and workflow

React / TypeScript application using Vinext, Vite, Cloudflare Workers, D1 and R2. package.json and pnpm-lock.yaml are the dependency authority.

```mermaid
flowchart TD
  U[Seller uploads] --> A[Authenticated API]
  A --> P[Parse and validate]
  P --> D[D1 version metadata]
  P --> R[R2 files and parsed records]
  D --> W[Seller workspace loader]
  R --> W
  W --> M[SKU mapping and calculations]
  M --> V[Dashboard and exports]
```

| Area | Files |
|---|---|
| Main UI/filter/upload state | app/workspace.tsx |
| Monthly overview | app/monthly-overview.tsx |
| Models/listings and period tables | app/performance-views.tsx |
| SKU × month | app/sku-month.tsx, lib/sku-month.ts |
| Returns | app/return-watch.tsx, lib/return-watch.ts |
| Charts | app/sales-charts.tsx, lib/chart-data.ts |
| GMV import/comparison/export | lib/gmv.ts, app/gmv-comparison.tsx, lib/gmv-export.ts |
| P&L/master/target parsing | lib/report.ts, lib/marketplace.ts |
| Settlement and return calculations | lib/performance.ts |
| Workspace API/version selection | app/api/workspace/route.ts |
| Identity/storage | lib/tenant.ts, lib/storage.ts, app/chatgpt-auth.ts |
| Schema/migrations | db/schema.ts, drizzle/*.sql |
| Local runtime/auth simulation | vite.config.ts, build/sites-vite-plugin.ts |

## Storage

D1 tables: legacy reports (month, object_key, filename, generated); legacy settings (id, value); documents (id, tenant, kind, logical_key, created, object_key). R2 holds parsed JSON and uploaded original files (`.source`). Current document kinds include report, master, settlement, gmv and settings. History is append-only; GET selects latest kind/logical key per tenant. The master merges platform/SKU mappings; settlement upload replaces the target list.

Owner maps to tenant `24energy`; other verified site users map to `seller:<id>`. Identity headers are trustworthy ONLY behind Sites' identity gateway. Source includes owner-only historical fallback seed data. Private hosting access is distinct from app tenant isolation; adding sellers still requires authorized site access.

## Performance

Memoized filtering/grouping; report-level WeakMap caches; paginated SKU/order tables; HTTP ETag for workspace reads. Preserve shared report objects when using caches. Updating immutable report content requires a new object; do not mutate cached report summaries in place.

## Known boundaries

Large raw files/data remain loaded per seller; not a full warehouse-query engine. Cross-platform imports use a standard template unless a native adapter exists. Current targets are not effective-dated. Negative settlement rows and target shortfall are different flags. Legacy cost code may exist but current app comparisons use settlement target maps.
