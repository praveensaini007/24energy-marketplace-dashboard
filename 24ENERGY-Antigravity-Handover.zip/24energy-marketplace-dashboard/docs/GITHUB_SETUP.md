# Private GitHub repository

Proposed name: **24energy-marketplace-dashboard**. Owner: the user's confirmed personal account or company organization. Visibility: **Private**. GitHub installation is confirmed; repository creation/push are pending because repository operations are not exposed in the current session.

## Recommended assisted path

Enable the GitHub plugin in ChatGPT. Once its connection is verified, resolve the repository owner, create the private repository and push this package. Do not ask the user to paste a token. Record the actual repository URL in HANDOVER.md. If repository creation is not supported by the connected integration, use the authenticated GitHub CLI or GitHub Desktop below; do not pretend the remote exists.

## GitHub Desktop alternative (Windows)

Extract this package. In GitHub Desktop, add the extracted folder as a local repository; if prompted that it is not a Git repository, create one at that existing folder. Review files, commit the initial snapshot, select Publish repository and keep **Keep this code private** checked. Verify the resulting repository displays Private. Do not initialize a different empty folder accidentally.

## CLI alternative

Run only in the extracted package, which deliberately contains no .git directory and no Sites Git credential. Install GitHub CLI and sign into the intended GitHub account via its browser login.

```sh
gh auth login
git init -b main
git add .
git commit -m "Import 24 ENERGY dashboard and handover documentation"
gh repo create 24energy-marketplace-dashboard --private --source=. --remote=origin --push
gh repo view --json nameWithOwner,url,isPrivate
```

If Git requests an author name/email, set your own identity through GitHub Desktop or git config first; do not copy an assistant identity. For organization ownership, use `ORGANIZATION/24energy-marketplace-dashboard` only after confirming the organization. Do not rerun creation if the name already exists; inspect it first. The included Actions workflow validates changes but does not deploy.

## Team workflow

Clone the same private repository in Antigravity and give Codex authorized access to it. Work on branches, push changes and review pull requests before merging to main. If supported by your GitHub plan, protect main and require the checks job. Branch protection has not been configured by this package.

Official references checked 5 October 2026:
- https://cli.github.com/manual/gh_repo_create
- https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github
- https://docs.github.com/en/desktop/overview/creating-your-first-repository-using-github-desktop
- https://www.antigravity.google/docs/projects
