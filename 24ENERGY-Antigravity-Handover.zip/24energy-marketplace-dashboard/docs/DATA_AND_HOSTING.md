# Data, authentication and hosting handoff

## What the ZIP contains

Tracked source snapshot plus new handover documentation, a local data-backup checklist and GitHub validation workflow. data/ contains the original bundled business seed JSON. It is confidential. There are no Git remote credentials, cookies, live environment files, dependency directories or full Git history.

## What is not backed up

Later uploads, their originals, replacements, live D1 metadata and live R2 objects are not exported here. A GitHub code repository is not a data backup. CSV/XLSX dashboard exports are useful business reports but do not contain all state needed for a full restore.

## Before any production migration

1. Obtain authorized export access to current D1 and R2 through supported platform operations. No general all-data export endpoint has been added by this package.
2. Capture a consistent backup of all seller-scoped documents metadata and referenced JSON/original objects, plus legacy reports/settings. Include active and historical versions and preserve object keys.
3. Store the backup privately outside Git; record backup time, object counts, hashes, schema/migration state and current source commit.
4. Provision separate staging D1/R2 (or explicitly planned replacements) and restore there.
5. Verify per-tenant report/month counts, mappings, targets, GMV date coverage, versions and totals; test seller isolation, uploads and downloads. Reconcile old vs new settlement/return results.
6. Only after validation and the user's cutover decision, move production traffic. Retain the old site for rollback and record any uploads made between backup and cutover.

## Keep Sites now

The current deployment uses `.openai/hosting.json` with DB and BUCKET logical bindings. Sites owns actual resources and trusted identity injection. The repository cannot reuse this hosting by copying credentials from a chat. Publishing continues through authorized Sites tooling.

GitHub branch changes do not automatically reach the Sites source repository. For each publish, the authorized publisher must review the intended GitHub commit, synchronize the approved application changes into the existing Sites checkout (preserving the same project identity), run required checks, and publish through Sites. Record both the GitHub commit and published Sites commit. This manual bridge is a documented workflow, not an installed integration.

## Independent hosting later

This is not a static HTML app or a drop-in Vercel deployment. It uses Workers APIs, D1/R2 bindings and Sites-provided identity. An independent deployment must provision owned backend resources and replace trusted-header auth with verified sessions plus membership checks. Strip/reject spoofed identity headers. Preserve tenant mapping and owner migration deliberately. Never solve login by making private reports public or removing authentication.

The included GitHub workflow only checks source; it contains no deployment token and cannot publish production.
