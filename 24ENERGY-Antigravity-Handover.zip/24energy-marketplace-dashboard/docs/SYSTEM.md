# Marketplace Intelligence — reporting release and handover

The user deferred the ASP calculator on 24 September 2026. Calculator UI and settlement-target uploads are not exposed in this reporting release. Pricing calculation/parser modules are retained for the next stage; descriptions below document those deferred modules. Current release: reporting, SKU/model mapping, costs, uploads, history and help.

## Purpose and scope
24 ENERGY is the first seller. Compare full order-cohort months across channels; aggregate listings into brand/model groups; distinguish listing packs from physical pieces; audit returns and reverse charges; plan ASP from settlement targets after all deductions.

## Workflow
```mermaid
flowchart TD
 A[Signed-in seller] --> B[SKU master]
 A --> C[Monthly report]
 C --> D{Validate format and quantities}
 D -->|Invalid| E[Correct and retry]
 D -->|Valid| F[Store immutable version]
 B --> G[Map SKU and pack size]
 F --> G
 G --> H[Platform and model reporting]
 H --> I[Category return evidence]
 J[Versioned settlement targets] --> K[ASP planner]
 I --> K
 L[Editable fee assumptions] --> K
```

## Source map
- `lib/report.ts`: original Flipkart workbook parser, summary/unit reconciliation.
- `lib/marketplace.ts`: normalized reports, master and target parsers, model matching, calculator.
- `lib/tenant.ts`: server-side authenticated identity and same-origin write check.
- `app/api/workspace/route.ts`: seller-scoped storage and version selection.
- `app/workspace.tsx`: reporting, uploads, calculator, costs and help.
- `app/classic`: retained original dashboard with month-specific historical costs.
- `db/schema.ts`, `drizzle`: append-only schema migrations.
- `data`: original seller's server-only seed data, never returned to other sellers.

## Identity and access
Private Site dispatch authenticates visitors and supplies authenticated user ID/email. Missing ID fails closed. The original seller is explicitly tied to the owner's verified dispatch email, not client input. Other signed-in users get independent seller keys from their authenticated ID. All document queries include tenant. Legacy report and cost endpoints are restricted to the original owner. Original seed data is returned only to that owner. Never expose this Worker directly without dispatch header protection. Site remains owner-private; access grants are a separate action. There is no public registration, staff membership, invitation UI or shared seller/team workspace in this release.

## Storage and history
D1 `documents`: ID, tenant, kind, logical key, ISO creation time, R2 object key. Index tenant/kind/key. R2 stores normalized JSON and original upload bytes. Latest report by tenant/platform/month is active. Prior versions remain immutable. Master uploads merge by platform/SKU; matching mappings are updated and other platform/SKU records retained. Original versions remain in history. Target uploads append; same effective-date keys resolve to newest upload. Settings snapshots preserve saved fee profiles and model costs. GET returns current reports plus audit metadata, not historic file contents. There is no restore/download-original UI yet.

Legacy original-owner reports remain available and are overridden only by a new report for the same platform/month. August fallback and SKU seed remain owner-only. No destructive migration or data backfill. Historical cost inputs remain in the classic dashboard and are not converted because their unit basis was different.

## Input contracts
Native Flipkart workbook requires Overall Summary, SKU-level P&L, Orders P&L. Its Shopsy channel stays separate in reporting but uploads as one Flipkart-source report. Full month only; duplicate item IDs or changed required headers fail. Native fees are signed amounts. Missing generated sales retain a visible report warning.

Other platforms: CSV/XLSX first sheet, exact header template available in app. One row per order item; one YYYY-MM cohort month per file. Required quantities are nonnegative integers and RTO+RVP+cancel cannot exceed gross. All monetary fields are required, including explicit confirmed zeros. Earnings After Ads is the all-in source earnings before product cost; do not deduct ads twice. Currency INR. This is normalized manual import, not a native adapter. No invented native fee policies. Blinkit B2B invoice/credit-note flows require consistent treatment by the preparer; customer return and warehouse RTV are not interchangeable.

SKU master: Platform, Brand, Category, Model No., Case Pack, SKU ID. Exact duplicate rows collapse; incomplete rows are excluded and counted; conflicting platform/SKU mappings reject entire upload. Platform names must match supported names. Exact channel/SKU match takes priority. Unique same-SKU match across another channel is provisional and flagged. Ambiguous/missing matches stay unmapped. Master edits currently remap all history: effective-dated master mappings are a future enhancement.

Targets: Platform, Brand, Model, Pack Size, Basis (piece/pack), Target Settlement, Effective From. A piece target multiplies by selected pack size. Latest target effective on or before scenario date wins. Same-date latest upload wins. Calculator manual target overrides are temporary; upload permanent revisions. Excel numeric dates and ISO strings are accepted. Zero target is valid.

## Metrics and monetary basis
- Unit return % = (RTO + RVP listing units) / gross listing units.
- RVP/RTO/cancel % use gross units independently.
- Order return % = distinct platform/order IDs with any return / all distinct platform/order IDs.
- Physical pieces = each listing's gross/return/net quantity × its pack size. Never multiply reported money by pack size.
- Net units = gross − RTO − RVP − cancellations, including any remaining open outcomes.
- All-platform earnings and net sales use report summary totals. Filtered/platform/model views use order amounts; account-level ads and adjustments are not allocated silently.
- RVP value means sales reversal, not reverse freight or full return loss.
- Reverse audit partitions item rows: any RVP; RTO with no RVP; fully cancelled with neither; remainder. Partial cancellation fees cannot be attributed to the cancelled unit without line-level evidence.
- Contribution = summary earnings − net pieces × product cost/piece − noncancelled listing units × packaging/pack. Missing mappings/costs block it. Filtered and model contribution estimates allocate report summary minus order earnings across gross listing units. Raw earnings never silently allocate ads; the UI labels the allocation basis. This is not measured model-level ad attribution. Costs currently apply to all selected months; saved history exists but historical costing is not automatic. No finalized accounting profit, tax filing or inventory valuation claims.

## ASP calculation
Seller price = ASP − CLF.
Deduct fixed fee, pick/pack, forward freight and commission (percentage of seller price), ads (% ASP), offer margin (% ASP; default 1.2), expected incremental return loss (return rate × loss per returned pack), entered fee GST, withholding (% seller price) and other deductions.
Fees fixed/pick/forward/commission are before entered GST. CLF, ads, offer, return loss and other amounts are all-in. Targets contain desired product cost and margin; do not subtract cost again. Reverse solver uses bisection, rounds upward to paise and verifies positive slope. Current calculator is single-rate: crossing a platform price/weight slab requires updating assumptions. Saved profiles are platform/model/pack/date-specific. No automatic official rate-card import. No automatic category ad attribution without an ad report. Fee review checkbox gates display of suggested ASP. Realization after ads and returns may differ from actual bank-payment timing.

## Verification and operation
`node scripts/verify-marketplace.mjs` checks original report totals, original master deduplication, pack mapping, return-rate math, target dates, normalized template validation, calculator arithmetic, solver and tenant identity. `node node_modules/typescript/bin/tsc --noEmit` checks types. Sites build creates Worker-compatible output; hosting applies generated D1 migrations. Never edit applied migrations. Preserve private access and check terminal deployment status.

## Future inputs and remaining roadmap
Native samples for Myntra/JioMart/Blinkit/website; target list; verified fee slabs with effective dates, zones, weights, fulfilment and payment type; per-listing ad attribution; product costs with historical dates; category code descriptions. Next stages: native adapters, effective-dated master/costs, automatic piecewise fee solver, settlement-bank reconciliation, restored versions UI, staff roles within seller accounts. No API credentials or marketplace integrations are required for the current upload workflow.

## Model drill-down and listing assessment (September 2026 update)
The global Model number selector filters overview, orders, monthly, model and listing views. Parent platform/brand/category changes reset the model; month changes preserve it. Clicking a model row sets the same selector. All models restores combined data. Models are keyed by brand + model, avoiding cross-brand merges.

`app/performance-views.tsx` provides the ranked listing view, category comparisons, and overall/year/month tables with CSV export. `lib/performance.ts` owns contribution, weighted return rate and assessment rules. Benchmark pool applies period/platform/brand/category filters BEFORE model filtering. It includes the selected model and only this seller's data. Category panel uses all pack sizes; listing assessment uses same channel, category and pack size. Monthly category benchmarks use the same months as the row. Year totals are selected uploaded months, not implicitly full years. Missing order expense fields display unavailable, never fabricated zero.

For a selected model, all master listings are visible, including zero-order listings. Assessment priority: exact mapping, minimum gross listing units (default 30, editable), no reported open return/in-transit outcomes, positive order earnings and positive contribution when costs exist, return rate no higher than category. Missing costs yield “Promising · add costs”, never a profit claim. Focus candidates sort by net sales; user can sort sales, return rate or earnings/unit. Sample threshold is a screening rule, not statistical significance. Fees/unit in period table use net listing units, explicitly labelled; category return rates always use gross listing units. No target or calculator fields were restored.

## SKU × month and responsiveness update
`lib/sku-month.ts` groups by platform + SKU and then cohort month. `app/sku-month.tsx` renders a paginated side-by-side matrix, metric selector, export and selectable SKU detail. Global model/category/brand/platform/month filters apply. Combined rates recompute from underlying units. Missing platform/month coverage says No report; zero activity within an uploaded report is zero; undefined ratios and missing costs say unavailable. Full Flipkart workbooks provide both Flipkart and Shopsy month coverage. Only listings with observed activity in the filtered selection appear in this matrix; the model listing view still includes zero-order master listings.

`app/model-search.tsx` composes the existing Popover and Command primitives for keyboard-accessible model/brand search and clear-to-All. It is also used for product-cost model entry.

Performance: master indexes replace per-order linear scans; immutable report totals are held in a WeakMap and reused by contribution calculations; filtered datasets are memoized; hidden tab JSX is not evaluated. Workspace GET fetches legacy report objects concurrently, excludes redundant SKU aggregates and unused classic cost/target payloads, and returns a tenant-specific ETag. Every GET authenticates before conditional responses; private no-cache means the browser must revalidate before reuse. Mutations change document revision IDs and invalidate ETags. Classic costs remain in the classic endpoint. No public/shared response cache is used. ETag seed version must change when seed or response semantics change. Tests compare old and indexed mapping/contribution output and cover weighted SKU/month totals, channel separation and missing-month coverage.

## Monthly return watchlist
Return watchlist appears in Returns & orders and SKU × month. Grouping is platform/SKU/month. Default is top 10 by combined RVP+RTO units, with RVP-only/RTO-only and top 5/20 alternatives. Highest-rate mode applies an editable minimum gross listing-unit threshold (30 default); unit mode keeps small samples but flags them. Rankings obey current filters. Category comparison is weighted within same month/channel/category/pack, independent of the selected model. Previous change requires the immediately preceding calendar month to be selected and have positive gross units for that SKU; no comparison to a non-adjacent month is implied. Open order rows and provisional mappings remain flagged. Red gaps indicate above-category rate, red changes indicate rising rates, all expressed as percentage points. All reverse fees are shown independently of the selected return type. Export contains currently ranked rows, metrics and caveat counts. Review prompts are hypotheses for investigation, not inferred return reasons. `lib/return-watch.ts` tests cover sample filtering, rankings, RVP/RTO and year-boundary previous month.

## Simplified navigation — current UI
Four main sections: Monthly overview, Models & SKUs, Returns to improve, Upload & settings. Overview retains the exact five-card structure requested: gross sales, net sales, combined RTO+RVP rate, platform/order earnings, contribution estimate. One monthly summary table below expands each month to show return quantities/values, expenses, fees, earnings, paid/pending and contribution. Overview ignores stored brand/category/model selections and exposes only platform/month filters.

Models & SKUs groups listings/category comparison, model-period results and SKU/month comparison into subviews. Removed the second listing table and duplicate monthly/platform pages. Returns to improve is the sole location of the return watchlist; the detailed fee audit/order explorer is collapsed beneath it. Upload & settings groups imports, SKU masters, history, product costs and help. Historical classic costs remain accessible from the cost explanation; legacy data/routes are untouched. No calculator or additional feature scope introduced. `app/monthly-overview.tsx` renders the consolidated month table; all monetary source and cost-allocation rules remain unchanged.

## Listing RVP columns
Ranked listing table adds RVP units and RVP fee / net unit beside RVP %. RVP units sum customer-return listing units. Fee numerator sums signed reverse fees on RVP-positive item rows, converted to deduction magnitude; RTO-only rows are excluded. Denominator is total net listing units in the selected period, matching the user's earlier report. This is not average fee per returned unit. No net units, or charged item rows containing both RTO and RVP, displays unavailable rather than guessing a split. Filters and combined-month aggregation remain unchanged.

### Model fee average and listing alerts
Model performance and focused listings share `averageRvpFee`: summed signed RVP reverse fees, negated, divided by summed net listing units. No average of SKU ratios; exclude RTO-only rows. Zero net units or charged mixed RTO/RVP rows produce unavailable. Focused listings show RTO listing-pack units. Red rows indicate negative aggregate reported bank settlement (only with complete bank coverage) or negative aggregate order earnings in the selected period; explicit labels distinguish cash settlement from earnings. Missing bank values never imply zero.

### Two-month RVP pricing recovery
Model and listing tables show a separate pricing allowance from the latest two distinct uploaded report months for the platform (Shopsy uses Flipkart uploads). Month selection does not change this baseline; the actual months and one-month fallback are disclosed beneath both tables. Brand/category/platform filters apply. Sum RVP fees divided by summed net listing packs, bounded at zero after fee credits. Mixed charged return rows or no net units are unavailable. This is a historical RVP-fee allowance per listing pack, not all return losses, not per physical piece and not a final ASP recommendation. Never modifies costs or profit. Indexed in one pass, memoized in the workspace.

### Flexible recovery and desired settlement targets (supersedes two-month rule)
Recovery follows selected months with no fixed limit and remains weighted by net listing units. Owner-only seed: 92 rows from Mp_Settelment.xlsx. Other sellers start without targets. Upload the same four columns to replace the current list; versions/source files remain in seller storage. Match exact normalized model, preserve category metadata, reject duplicate model keys and invalid values. UI basis selector defaults to Taxed NLC but supports Base NLC. Each listing target is per-piece value times mapped pack size; aggregate model target weights by net listing units. Missing mapping/targets stays unavailable. Target is after all user-specified expenses. Target plus RVP allowance is explicitly only an intermediate pricing subtotal, not an all-expense ASP or verified settlement shortfall. Existing actual settlement figures are not assumed to cover every expense. Targets apply as current planning inputs, not historical effective-date targets.

### Period RVP fee per returned unit
Overall, yearly and monthly tables and their shared CSV export include RVP fee / returned unit. Numerator is negated signed reverse fees on RVP rows; denominator is summed RVP returned listing packs. Exclude RTO-only fees. Zero returns and unsplittable charged mixed RTO/RVP rows show unavailable. Aggregate periods use ratio of totals. Existing reverse-fee/net-unit recovery metrics are unchanged.

### Weekly GMV comparison and combined export
Native earn_more_report import is separate from P&L. 1,423 seed records from earn_more_report (3).xlsx (4 Sep–3 Oct 2026; GMV 1,854,157) are served only to the owner. Other sellers start empty. `gmv` documents use the existing tenant-scoped, versioned R2/D1 storage. Complete replacement of incoming min/max dates retains data outside that range; repeat uploads do not accumulate. Upload guidance requires both Flipkart and Shopsy for the complete period. Original bytes are retained. Native category/vertical Shopsy prefixes determine channel; exact platform/SKU master determines model. Parser validates dates, numerical values and reconciliation; negative final sales caused by returns are valid. Duplicate natural keys are rejected when values conflict, identical duplicates collapse.
GMV comparison defaults to latest date minus 27 days and shows four 7-day windows. User can change start date and compare adjacent weeks. Global platform/model/brand/category filters apply; global order-month selection applies only to P&L part of export. Partial coverage means fewer than 7 source dates and suppresses growth percentages. GMV is gross sales from the GMV source, not accounted P&L sales.
Excel download follows the provided example structure: Overview, SKU comparison, SKU settlements, RVP fee source, Breakdowns, Source data, SKU source and Account source. The latter holds unfiltered controls and is clearly labelled. Export preserves numeric values/percentage formats and includes all filtered rows independently of SKU search/pagination. GMV and P&L dates are explicit. Missing order-level financial values remain unavailable, never filled from a different period. Source IDs are strings. Browser export loads the workbook library only when requested.

### Vertical GMV summary
GMV view provides a searchable vertical selector (source Vertical, not master Category), all verticals reset, and a four-week summary with explicit ranges, total GMV, selected adjacent-week change/growth and gross units. Clicking a summary vertical filters the GMV cards/listings. Missing verticals are Unknown vertical. Export includes a Vertical summary sheet and vertical breakdowns. Vertical applies to GMV only; P&L retains independent platform/model/month filters, explicitly labelled in UI and export. Totals sum source rows once and partial-week growth remains unavailable.

### Interactive sales and GMV graphs
Sales graphs tab uses selected P&L months and the existing platform/brand/category/model scope. A searchable SKU selector narrows only the graphs. Monthly plots show gross/net sales, RTO/RVP quantities and projected bank settlement. Overall without detailed filters can use report-summary totals; SKU/detailed views require order-level settlement/gross fields. Missing fields stay null, never zero. Exact values are available in an accessible disclosure. GMV comparison includes a weekly trend with a separate graph-only SKU selector, respecting vertical/platform/model and weekly ranges. Tooltips include date range and coverage. Partial GMV is labelled and missing periods leave gaps. Recharts uses accessibilityLayer and responsive frames.

### Flexible GMV exports and weekly history
Separate GMV-only (five GMV sheets) and GMV+P&L downloads share inclusive export start/end dates, independent of the 4-week on-screen comparison. All saved dates shortcut available. Export groups any range into seven-day windows from its start, clips the final window to selected end, and labels partial coverage. Single-period exports have no comparative growth. P&L remains the full selected order months, explicitly disclosed. Export filenames include range. GMV-only contains no P&L sheets or summary. Weekly upload merge retains dates outside incoming interval and replaces overlapping interval; saved document history retains prior versions.

### Month-based GMV views
Default GMV period is latest uploaded calendar month. Month selector derives from saved dates and updates with uploads. Weeks anchor on days 1,8,15,22,29 and stop at month-end. Missing weeks say Not uploaded; coverage is explicit. Comparison defaults to latest week containing data and requires two complete seven-day periods for percentage growth. Custom range and All saved dates use the same inclusive range for screen cards, plots, tables and export. Comparison and export now share selected periods. Monthly P&L scope remains independently labelled.

### Period comparison indicators
Month-wise and Year-wise metrics compare with the immediately preceding calendar period in the selection. Missing previous periods or metrics and unchanged values stay neutral. Values and arrows share the comparison colour. RTO/RVP units, cancellations, return rates and fee metrics treat decreases as favourable (green ▲), increases as unfavourable (red ▲), per the owner's requested arrow convention. Signed expense deductions are negated for comparison, so -100 versus -200 is a cost reduction; credits are preserved, not converted with absolute value. Other metrics retain green ▲ for increases and red ▼ for decreases. Hover text gives actual direction and baseline. Comparison rounds to displayed two-decimal precision. Year totals use selected uploaded months; coverage may differ. CSV exports retain plain numeric values.

### Settlement target performance (current workspace)
Product-cost entry is retired. Current overview, models, focused listings, period tables, SKU matrix and exports use surplus/shortfall against the uploaded settlement targets. The old classic route redirects to the current workspace; saved historical cost records remain intact.
Formula: sum(order bank settlement + allocated report bank residual) minus sum(net listing units × case pack × Taxed NLC per piece). Report residual = projected summary bank settlement − sum of all order bank settlements; allocate it by gross units over the entire report, before filtering. This reconciles account-level ads, taxes, fees and other adjustments once. All returns/cancellations and their settlement charges remain in the actual numerator, even at zero net units. Missing required bank data or targets return unavailable rather than a partial figure. Taxed NLC is used for cash comparisons; the Base/Taxed selector affects planning targets only. Current replacement target lists also re-evaluate historical comparisons, as labelled in the upload screen. This is a projected settlement target variance, not accounting profit or confirmed cash receipt.
