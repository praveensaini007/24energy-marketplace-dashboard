# Current business rules

This document records the latest user-approved rules and takes precedence over older contribution wording in SYSTEM.md / starter references.

## Units, mappings and returns

Model has multiple platform listings. Match platform + SKU first; flag fallback channel matches and unmapped rows. Case pack means physical pieces per listing pack (1 or 2), not a shipping carton. Gross/net/RTO/RVP quantities are listing units. Physical pieces = quantity × that listing's case pack.

RVP = customer returns; RTO = logistics returns. Do not rename RVP as return-to-vendor. RTV only where the source explicitly uses that term. Return rate = (RVP units + RTO units) / gross ordered units; cancellations are separate. RVP rate = RVP / gross units. Aggregate percentages by summed numerators/denominators, never by averaging monthly percentages. Report charges, not universal platform policy, determine whether reverse fees occur on RTO/cancelled orders.

## Settlement targets replace extra product cost

The target list contains per-piece (Pack of 1) amounts already including product cost and desired margin after expenses. Current cash comparisons use Taxed NLC. For each order line, required settlement = net listing units × case pack × Taxed NLC. Sum per-line targets across different models/packs. Never multiply reported currency again by case pack.

Adjusted reported settlement = order bank settlement + allocated account-level residual. Report residual = report's projected bank settlement − sum of all its order bank settlements. Allocate residual by gross listing units across the complete report before filtering. It captures unallocated ads/fees/adjustments once. This allocation is an estimate for individual listings, not direct ad attribution.

Surplus / shortfall = adjusted reported settlement − required settlement. Positive is above the desired target; negative is below it; zero meets it. It is NOT accounting profit or confirmed cash received. Product cost, ads, CLF, taxes, return fees and offers already included in the report must not be deducted again. Return/cancel rows still contribute their settlement charges when net units are zero. Missing target for net sold units or missing required bank data gives unavailable, not a partial result. No net target is charged for returned units.

Current uploaded targets re-evaluate any historical months selected. Effective-dated historical target versions are not implemented. Base/Taxed selector changes planning columns only; cash target variance always uses Taxed NLC. Current UI no longer requests separate product or packaging costs.

## RVP fee metrics

RVP fee / returned unit = negative of signed reverse fees on RVP rows / RVP returned listing units. Exclude RTO-only fees. If charged rows contain both RTO and RVP and cannot be split, show unavailable. Zero denominator is unavailable.

RVP fee / net unit = eligible RVP reverse fees / total net sold listing units. Recovery allowance = max(0, that value), over all selected uploaded months. Target + RVP allowance is a planning intermediate, not final ASP; never deduct this allowance again in observed settlement variance.

## Time and indicators

Month/year comparisons use previous calendar period within the selection. Missing previous period gives no arrow. Year totals cover selected uploaded months; coverage may differ. RTO, RVP, cancellations, return rates and fees: decreased burden is green value + green ▲; increased burden is red value + red ▲. Signed expense amounts are negated for burden comparison. Other metrics use green ▲ for increases and red ▼ for decreases. Unchanged is neutral.

GMV is separate from P&L. Month weeks: days 1–7, 8–14, 15–21, 22–28 and 29–month end. Show dates, support selected ranges, retain unuploaded weeks as missing. Weekly refresh replaces the full overlapping uploaded interval; it must cover all relevant channels. Never simply add overlapping reports. P&L refresh replaces current platform/month version while retaining history.

## Deferred calculator

ASP calculator is deferred. Future offer margin is 1.2% of ASP per user input, configurable rather than asserted as a universal platform rate. CLF in the supplied screenshot means Customer Logistics Fees. Verify each platform's fee basis from actual source files before implementation. Do not invent fee schedules or tax treatment.
