# Codex ↔ Antigravity workflow

## Before starting

Read AGENTS.md and HANDOVER.md. Inspect `git status` and recent log. Fetch/pull the intended remote branch without overwriting local work. Confirm the latest user request and deployment status. Use a task branch such as `feature/settlement-export`.

## Before handing off

1. Save and review all changes.
2. Run relevant checks and record exact results.
3. Update HANDOVER.md: completed change, files touched, what remains, blockers, tests, branch and last deployed version.
4. Commit and push. Use `git log -1` to identify the handoff commit; no need to place the current commit hash inside its own contents.
5. Next assistant pulls that branch and continues. Never assume it has the ChatGPT conversation.

## Production

Merge approved work to main. GitHub CI validates but does not publish. Follow DATA_AND_HOSTING for the separate Sites publication and record its confirmed result. Keep a known-working source revision for rollback. Do not overwrite one platform's newer changes from an older ZIP.

## No automatic token-limit switch

Switching assistants is manual: save and push at a useful checkpoint before reaching any usage limit. There is no configured automatic Antigravity trigger or conversation transfer. This document and the Git branch provide continuity.
