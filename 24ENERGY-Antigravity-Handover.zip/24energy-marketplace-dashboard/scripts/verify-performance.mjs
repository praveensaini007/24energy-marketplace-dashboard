import ts from 'typescript';import fs from 'node:fs';import assert from 'node:assert/strict';
const dir='.sites-runtime/performance-tests';fs.mkdirSync(dir,{recursive:true});for(const f of ['report','marketplace','performance','sku-month','return-watch','gmv']){const src=fs.readFileSync(`lib/${f}.ts`,'utf8').replaceAll("'./report'","'./report.mjs'").replaceAll("'./marketplace'","'./marketplace.mjs'").replaceAll("'./performance'","'./performance.mjs'");fs.writeFileSync(`${dir}/${f}.mjs`,ts.transpileModule(src,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);}
const {assessListing,returnRate}=await import(`../${dir}/performance.mjs`);
const report={summary:{'earnings on platform':500},orders:[]};
const base={id:'1',item:'1',sku:'A',channel:'Flipkart',status:'DELIVERED',month:'2026-08',report,state:'Matched',gross:100,net:90,rto:0,rvp:10,cancel:0,sales:1000,reverse:-20,earnings:500,pending:0,master:{brand:'B',model:'M',category:'C',pack:1,platform:'Flipkart',sku:'A'}};report.orders=[base];
const peer={...base,sku:'B',gross:10,net:5,rvp:5,master:{...base.master,model:'OTHER',sku:'B'}};
assert.equal(returnRate([base,peer]),15/110);
const pool=[base,peer];assert.equal(assessListing([base],pool,{}).label,'Promising · add costs');assert.equal(assessListing([base],pool,{'b|m':{product:1,packaging:1}}).label,'Focus candidate');
assert.equal(assessListing([{...base,gross:2}],pool,{}).label,'Small sample');assert.equal(assessListing([{...base,status:'RETURN_REQUESTED'}],pool,{}).label,'Await final outcomes');assert.equal(assessListing([{...base,state:'Channel differs'}],pool,{}).label,'Review mapping');assert.equal(assessListing([],pool,{}).label,'No orders');
assert.equal(assessListing([base],[...pool,{...peer,channel:'Shopsy',rvp:10},{...peer,master:{...peer.master,pack:2},rvp:10}],{}).peerRate,15/110);
assert.equal(assessListing([base],pool,{'b|m':{product:100,packaging:1}}).label,'Review earnings');
console.log('PASS: weighted benchmark, independent model baseline, same-channel/pack peers, missing costs, small samples, open returns, mapping gaps and no-order listings.');

const {skuMonthGroups,metricValue,coverage}=await import(`../${dir}/sku-month.mjs`);
const later={...base,month:'2026-09',gross:20,rvp:8,net:12,sales:200};
const matrix=skuMonthGroups([base,later,{...peer,channel:'Shopsy',sku:base.sku}]);
assert.equal(matrix.length,2);assert.equal(matrix.find(g=>g.channel==='Flipkart').months.size,2);
assert.equal(metricValue([base,later],'returns',{}),15);assert.equal(metricValue([base,later],'sales',{}),1200);
assert.equal(metricValue([],'returns',{}),null);assert.equal(metricValue([],'sales',{}),0);
const covered=coverage([{...report,platform:'Flipkart',month:'2026-08'}]);assert(covered.has('2026-08|shopsy'));assert(!covered.has('2026-09|flipkart'));
console.log('PASS: SKU/month separation, weighted combined rate, metric totals and missing-month coverage.');

const {returnWatch,rankReturns,previousMonth}=await import(`../${dir}/return-watch.mjs`);
assert.equal(previousMonth('2026-01'),'2025-12');
const small={...base,sku:'SMALL',gross:1,rvp:1,rto:0};const big={...base,sku:'BIG',gross:100,rvp:20,rto:10};
const watch=returnWatch([small,big,{...big,month:'2026-09',rvp:30}],[small,big],'all');
assert.equal(rankReturns(watch,'2026-08','units',30)[0].sku,'BIG');assert.equal(rankReturns(watch,'2026-08','rate',30).length,1);
assert.equal(rankReturns(watch,'2026-08','rate',1)[0].sku,'SMALL');assert.equal(watch.find(r=>r.month==='2026-09').change,10);
assert.equal(returnWatch([big],[big],'rvp')[0].returned,20);assert.equal(returnWatch([big],[big],'rto')[0].returned,10);
console.log('PASS: monthly return ranking, sample threshold, RVP/RTO split and previous calendar-month changes.');

const {averageRvpFee,listingFinancialAlert}=await import(`../${dir}/performance.mjs`);
assert.equal(averageRvpFee([{...base,net:10,reverse:-100},{...base,net:90,reverse:-200}]),3);
assert.equal(averageRvpFee([{...base,net:0}]),null);
assert.equal(averageRvpFee([{...base,rto:1}]),null);
assert.equal(averageRvpFee([{...base,rvp:0,rto:10}]),0);
assert.equal(listingFinancialAlert([{...base,bank:-10}]).negativeBank,true);
assert.equal(listingFinancialAlert([{...base,bank:-10},base]).bank,null);
assert.equal(listingFinancialAlert([{...base,earnings:-10}]).label,'Negative earnings');
assert.equal(listingFinancialAlert([base]).flagged,false);
assert.equal(listingFinancialAlert([]).flagged,false);
console.log('PASS: weighted RVP fee, ambiguous returns, missing bank coverage and negative listing alerts.');

const {rvpRecoveryIndex,indexMaster}=await import(`../${dir}/performance.mjs`);
const recovery=rvpRecoveryIndex([{platform:'Flipkart',month:'2026-07',orders:[{...base,reverse:-9999}]},{platform:'Flipkart',month:'2026-08',orders:[{...base,net:10,reverse:-100}]},{platform:'Flipkart',month:'2026-09',orders:[{...base,net:90,reverse:-200}]}],indexMaster([base.master]),'Flipkart','All brands','All categories',['2026-08','2026-09']);
assert.deepEqual(recovery.months,['2026-08','2026-09']);assert.equal(recovery.models.get('b|m'),3);assert.equal(recovery.listings.get('flipkart|a'),3);
console.log('PASS: latest two months, weighted model/listing recovery and older-month exclusion.');

const {desiredSettlement}=await import(`../${dir}/performance.mjs`);
const targets=new Map([['m',{model:'M',category:'C',base:127,taxed:149.86}]]);
assert.equal(desiredSettlement([{...base,master:{...base.master,pack:2}}],targets,'taxed'),299.72);
assert.equal(desiredSettlement([base],new Map(),'taxed'),null);
assert.equal(rvpRecoveryIndex([{platform:'Flipkart',month:'2026-07',orders:[base]},{platform:'Flipkart',month:'2026-08',orders:[base]},{platform:'Flipkart',month:'2026-09',orders:[base]}],indexMaster([base.master]),'Flipkart','All brands','All categories').months.length,3);
console.log('PASS: flexible months, case-pack settlement multiplication and missing targets.');

const {rvpFeePerReturnedUnit}=await import(`../${dir}/performance.mjs`);
assert.equal(rvpFeePerReturnedUnit([{...base,rvp:20,reverse:-3000,net:100}]),150);
assert.equal(rvpFeePerReturnedUnit([{...base,rvp:2,reverse:-200},{...base,rvp:8,reverse:-1600}]),180);
assert.equal(rvpFeePerReturnedUnit([{...base,rvp:0,rto:10,reverse:-500}]),null);
assert.equal(rvpFeePerReturnedUnit([{...base,rvp:2,reverse:-200},{...base,rvp:0,rto:10,reverse:-500}]),100);
assert.equal(rvpFeePerReturnedUnit([{...base,rto:1}]),null);
assert.equal(rvpFeePerReturnedUnit([{...base,reverse:0}]),0);
console.log('PASS: RVP returned-unit denominator, weighted periods, RTO exclusion and unavailable cases.');

// Settlement targets replace product-cost entry in the current workspace.
const {settlementVariance}=await import(`../${dir}/performance.mjs`);
const cashReport={summary:{'bank settlement (projected)':260},orders:[]};
const cashA={...base,report:cashReport,gross:2,net:2,bank:210,master:{...base.master,pack:1}};
const cashB={...base,report:cashReport,gross:2,net:1,bank:90,master:{...base.master,pack:2}};
cashReport.orders=[cashA,cashB];
const settlementTargets=new Map([['m',{model:'M',category:'C',base:80,taxed:100}]]);
assert.equal(settlementVariance([cashA,cashB],settlementTargets),-140); // 260 minus 400 target, no second fee deduction
assert.equal(settlementVariance([cashA],settlementTargets),-10); // 210 minus 20 allocated account charges minus 200 target
assert.equal(settlementVariance([cashB],settlementTargets),-130);
assert.equal(settlementVariance([cashA],new Map()),null);
assert.equal(settlementVariance([{...cashA,bank:undefined}],settlementTargets),null);
const returnReport={summary:{'bank settlement (projected)':-50},orders:[]};
const returned={...cashA,report:returnReport,net:0,bank:-50};returnReport.orders=[returned];
assert.equal(settlementVariance([returned],settlementTargets),-50);
assert.equal(metricValue([cashA],'profit',settlementTargets),-10);
console.log('PASS: cash target variance, case packs, account expense allocation, missing inputs, return-only losses and SKU matrix.');
