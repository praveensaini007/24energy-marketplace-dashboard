import ts from 'typescript';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import * as XLSX from 'xlsx';
const dir='.sites-runtime/verification';fs.mkdirSync(dir,{recursive:true});
for(const file of ['report','marketplace','tenant']){let s=fs.readFileSync(`lib/${file}.ts`,'utf8').replace("'./report'","'./report.mjs'");fs.writeFileSync(`${dir}/${file}.mjs`,ts.transpileModule(s,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText);}
const {parseMarket,parseMaster,parseTargets,calculate,solve,defaultFees,mapping}=await import(`../${dir}/marketplace.mjs`);
const {identity}=await import(`../${dir}/tenant.mjs`);
const bytes=p=>{const b=fs.readFileSync(p);return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)};
const root='/workspace/scratch/95e99227eb4b/upload/';
const report=parseMarket(bytes(root+'f7eb5994-5fa3-4b56-9f57-e7f8ba5c70e8_1789986134000.xlsx'),'august.xlsx','Flipkart');
assert.equal(report.orders.reduce((a,o)=>a+o.gross,0),6103);
assert.equal(report.orders.reduce((a,o)=>a+o.rvp,0),787);
const master=parseMaster(bytes(root+'01-FK_SKU_Master.xlsx'));assert.equal(master.items.length,1143);assert.equal(master.skipped,12);
assert.equal(mapping(master.items,{channel:'Shopsy',sku:'BCWC259'}).state,'Channel differs');
const seed=JSON.parse(fs.readFileSync('data/august.json'));assert.equal(seed.orders.length,report.orders.length);
const f={...defaultFees,clf:109,fixed:5.6,tax:18,ads:8};assert.ok(Math.abs(calculate(389,f).settlement-237.604)<1e-8);assert.equal(solve(237.604,f),389);
assert.equal(calculate(100,{...defaultFees,returnRate:20,returnCost:50}).parts['Return provision'],10);
function book(rows){const w=XLSX.utils.book_new();XLSX.utils.book_append_sheet(w,XLSX.utils.json_to_sheet(rows),'Sheet1');return XLSX.write(w,{type:'array',bookType:'xlsx'});}
assert.equal(parseTargets(book([{Platform:'Flipkart',Brand:'24ENERGY',Model:'EN-985','Pack Size':2,Basis:'piece','Target Settlement':200,'Effective From':'2026-09-01'}]))[0].amount,200);
assert.throws(()=>parseTargets(book([{Platform:'Flipkart',Brand:'24ENERGY',Model:'EN-985','Pack Size':0,Basis:'piece','Target Settlement':200,'Effective From':'2026-09-01'}])));
const row={Month:'2026-09','Order ID':'O1','Item ID':'I1',SKU:'A',Status:'DELIVERED','Gross Units':2,'RTO Units':0,'RVP Units':1,'Cancelled Units':0,'Gross Sales':500,'Net Sales':250,'RTO Value':0,'RVP Value':250,'Reverse Fee':30,'Earnings After Ads':200,'Bank Settlement':190,Paid:190,'Pending Settlement':0,Ads:10};
assert.equal(parseMarket(book([row]),'x.xlsx','Myntra').orders[0].net,1);assert.throws(()=>parseMarket(book([row,row]),'x.xlsx','Myntra'));assert.throws(()=>parseMarket(book([{...row,'RVP Units':3}]),'x.xlsx','Myntra'));
assert.throws(()=>identity(new Request('https://example.test')));const who=id=>identity(new Request('https://example.test',{headers:{'oai-authenticated-user-id':id}}));assert.notEqual(who('a').tenant,who('b').tenant);assert.equal(who('a').owner,false);
console.log('PASS: original reports, master mapping, normalized imports, target validation, return provision, ASP solver and tenant isolation.');
